create view productcustomers as
select `crashcourse`.`customers`.`cust_name`    AS `cust_name`,
       `crashcourse`.`customers`.`cust_contact` AS `cust_contact`,
       `crashcourse`.`orderitems`.`prod_id`     AS `prod_id`
from `crashcourse`.`customers`
         join `crashcourse`.`orders`
         join `crashcourse`.`orderitems`
where ((`crashcourse`.`customers`.`cust_id` = `crashcourse`.`orders`.`cust_id`) and
       (`crashcourse`.`orderitems`.`order_num` = `crashcourse`.`orders`.`order_num`));

-- comment on column productcustomers.cust_name not supported: 顾客名

-- comment on column productcustomers.cust_contact not supported: 顾客的联系名

-- comment on column productcustomers.prod_id not supported: 产品ID

