create view customeremaillist as
select `crashcourse`.`customers`.`cust_id`    AS `cust_id`,
       `crashcourse`.`customers`.`cust_name`  AS `cust_name`,
       `crashcourse`.`customers`.`cust_email` AS `cust_email`
from `crashcourse`.`customers`
where (`crashcourse`.`customers`.`cust_email` is not null);

-- comment on column customeremaillist.cust_id not supported: 唯一的顾客ID

-- comment on column customeremaillist.cust_name not supported: 顾客名

-- comment on column customeremaillist.cust_email not supported: 顾客的联系email地址

