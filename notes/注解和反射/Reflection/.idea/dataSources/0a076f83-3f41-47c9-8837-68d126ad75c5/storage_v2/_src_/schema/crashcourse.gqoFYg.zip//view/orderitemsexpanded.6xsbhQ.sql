create view orderitemsexpanded as
select `crashcourse`.`orderitems`.`order_num`                                            AS `order_num`,
       `crashcourse`.`orderitems`.`prod_id`                                              AS `prod_id`,
       `crashcourse`.`orderitems`.`quantity`                                             AS `quantity`,
       `crashcourse`.`orderitems`.`item_price`                                           AS `item_price`,
       (`crashcourse`.`orderitems`.`quantity` * `crashcourse`.`orderitems`.`item_price`) AS `expanded_price`
from `crashcourse`.`orderitems`;

-- comment on column orderitemsexpanded.order_num not supported: 订单号

-- comment on column orderitemsexpanded.prod_id not supported: 产品ID

-- comment on column orderitemsexpanded.quantity not supported: 物品数量

-- comment on column orderitemsexpanded.item_price not supported: 物品价格

